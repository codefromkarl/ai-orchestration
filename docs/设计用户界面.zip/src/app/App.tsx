import { useState, useEffect } from 'react';
import { TopNav } from './components/TopNav';
import { KanbanBoard } from './components/KanbanBoard';
import { CommandCenter } from './components/CommandCenter';
import { TaskTable } from './components/TaskTable';
import { DetailDrawer } from './components/DetailDrawer';
import { ModelConfigDrawer } from './components/ModelConfigDrawer';
import { SystemConfigDrawer, Theme } from './components/SystemConfigDrawer';
import { WorkItem, CommandMessage } from './types';
import { mockWorkItems, mockAttentionItems, mockCommandHistory } from './data/mock-data';
import { applyTheme, getStoredTheme } from './utils/theme-utils';

export default function App() {
  const [activeTab, setActiveTab] = useState('kanban');
  const [selectedItem, setSelectedItem] = useState<WorkItem | null>(null);
  const [commandHistory, setCommandHistory] = useState<CommandMessage[]>(mockCommandHistory);
  const [isModelConfigOpen, setIsModelConfigOpen] = useState(false);
  const [isSystemConfigOpen, setIsSystemConfigOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<Theme>(getStoredTheme());

  // Apply theme on mount and when theme changes
  useEffect(() => {
    applyTheme(currentTheme);
    
    // Apply theme class to document
    document.documentElement.classList.remove('dark', 'theme-cyberpunk', 'theme-programmer');
    if (currentTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (currentTheme === 'cyberpunk') {
      document.documentElement.classList.add('theme-cyberpunk');
    } else if (currentTheme === 'programmer') {
      document.documentElement.classList.add('theme-programmer');
    }
  }, [currentTheme]);

  const handleThemeChange = (theme: Theme) => {
    setCurrentTheme(theme);
  };

  const handleSendCommand = (command: string) => {
    const userMessage: CommandMessage = {
      id: `msg-${Date.now()}-user`,
      type: 'user',
      content: command,
      timestamp: new Date(),
    };

    const systemMessage: CommandMessage = {
      id: `msg-${Date.now()}-system`,
      type: 'system',
      content: `收到指令：${command}。正在处理...`,
      timestamp: new Date(),
    };

    setCommandHistory([...commandHistory, userMessage, systemMessage]);
  };

  const handleCardClick = (item: WorkItem) => {
    setSelectedItem(item);
  };

  const handleCloseDrawer = () => {
    setSelectedItem(null);
  };

  return (
    <div className="h-screen flex flex-col" style={{ backgroundColor: 'var(--color-background)' }}>
      {/* Top Navigation */}
      <TopNav 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        onOpenModelConfig={() => setIsModelConfigOpen(true)}
        onOpenSystemConfig={() => setIsSystemConfigOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Tab Content */}
        <div className="flex-1 overflow-hidden">
          {activeTab === 'kanban' && (
            <KanbanBoard items={mockWorkItems} onCardClick={handleCardClick} />
          )}
          {activeTab === 'command' && (
            <CommandCenter
              attentionItems={mockAttentionItems}
              commandHistory={commandHistory}
              onSendCommand={handleSendCommand}
            />
          )}
          {activeTab === 'repository' && (
            <TaskTable items={mockWorkItems} onRowClick={handleCardClick} />
          )}
        </div>

        {/* Detail Drawer */}
        {selectedItem && <DetailDrawer item={selectedItem} onClose={handleCloseDrawer} />}
      </div>

      {/* Model Config Drawer */}
      <ModelConfigDrawer 
        isOpen={isModelConfigOpen} 
        onClose={() => setIsModelConfigOpen(false)} 
      />

      {/* System Config Drawer */}
      <SystemConfigDrawer 
        isOpen={isSystemConfigOpen} 
        onClose={() => setIsSystemConfigOpen(false)}
        currentTheme={currentTheme}
        onThemeChange={handleThemeChange}
      />
    </div>
  );
}