// Type definitions for Stardrifter Console

export type TaskStatus = 'pending' | 'ready' | 'in_progress' | 'verifying' | 'blocked' | 'done';

export type Priority = 'governance' | 'core_path' | 'cross_cutting';

export interface WorkItem {
  number: number;
  title: string;
  type: 'epic' | 'story' | 'task';
  status: TaskStatus;
  epicNumber?: number;
  storyNumber?: number;
  priority: Priority;
  lane?: string;
  wave?: string;
  complexity?: number;
  blockedReason?: string;
  decisionRequired?: boolean;
  githubUrl?: string;
}

export interface AttentionItem {
  id: string;
  issueNumber: number;
  title: string;
  priorityScore: number;
  reason: string;
}

export interface CommandMessage {
  id: string;
  type: 'user' | 'system';
  content: string;
  timestamp: Date;
}
