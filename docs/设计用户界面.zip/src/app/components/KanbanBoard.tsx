import { WorkItem, TaskStatus } from '../types';
import { Badge } from './Badge';

interface KanbanCardProps {
  item: WorkItem;
  onClick: () => void;
}

function KanbanCard({ item, onClick }: KanbanCardProps) {
  return (
    <div
      onClick={onClick}
      className="p-3 border rounded-lg shadow-sm cursor-pointer transition-all duration-180 hover:shadow-md hover:-translate-y-0.5"
      style={{ 
        borderColor: 'var(--color-border)', 
        backgroundColor: 'var(--color-surface)' 
      }}
    >
      <div className="space-y-2">
        {/* Title */}
        <div className="flex items-start gap-2">
          <span className="text-sm font-medium shrink-0" style={{ color: 'var(--color-text-secondary)' }}>#{item.number}</span>
          <span className="text-sm line-clamp-2" style={{ color: 'var(--color-text)' }}>{item.title}</span>
        </div>

        {/* Badge & Meta */}
        <div className="flex items-center justify-between">
          <Badge status={item.status} />
          {item.blockedReason && (
            <span className="text-xs text-red-600 font-medium">{item.blockedReason}</span>
          )}
        </div>
      </div>
    </div>
  );
}

interface KanbanColumnProps {
  title: string;
  items: WorkItem[];
  onCardClick: (item: WorkItem) => void;
}

function KanbanColumn({ title, items, onCardClick }: KanbanColumnProps) {
  return (
    <div className="flex-1 min-w-0">
      <div className="rounded-lg p-4 h-full" style={{ backgroundColor: 'var(--color-surface-hover)' }}>
        {/* Column Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold" style={{ color: 'var(--color-text)' }}>{title}</h3>
          <span className="text-sm font-medium" style={{ color: 'var(--color-text-secondary)' }}>{items.length}</span>
        </div>

        {/* Cards */}
        <div className="space-y-3 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 220px)' }}>
          {items.map((item) => (
            <KanbanCard key={item.number} item={item} onClick={() => onCardClick(item)} />
          ))}
        </div>
      </div>
    </div>
  );
}

interface KanbanBoardProps {
  items: WorkItem[];
  onCardClick: (item: WorkItem) => void;
}

export function KanbanBoard({ items, onCardClick }: KanbanBoardProps) {
  // Group items by column
  const todoStatuses: TaskStatus[] = ['pending', 'ready'];
  const doingStatuses: TaskStatus[] = ['in_progress', 'verifying', 'blocked'];
  const doneStatuses: TaskStatus[] = ['done'];

  const todoItems = items.filter((item) => todoStatuses.includes(item.status));
  const doingItems = items.filter((item) => doingStatuses.includes(item.status));
  const doneItems = items.filter((item) => doneStatuses.includes(item.status));

  return (
    <div className="flex gap-4 h-full p-6">
      <KanbanColumn title="待办 (To Do)" items={todoItems} onCardClick={onCardClick} />
      <KanbanColumn title="进行中 (Doing)" items={doingItems} onCardClick={onCardClick} />
      <KanbanColumn title="已完成 (Done)" items={doneItems} onCardClick={onCardClick} />
    </div>
  );
}