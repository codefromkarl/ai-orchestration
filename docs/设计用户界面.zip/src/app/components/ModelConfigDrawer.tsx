import { useState } from 'react';
import { X, Plus, Trash2, Edit } from 'lucide-react';
import { Button } from './Button';

interface ModelRoute {
  id: string;
  name: string;
  endpoint: string;
  apiKey: string;
  priority: number;
}

interface Skill {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
}

interface MCPServer {
  id: string;
  name: string;
  url: string;
  status: 'connected' | 'disconnected';
}

interface ModelConfigDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ModelConfigDrawer({ isOpen, onClose }: ModelConfigDrawerProps) {
  const [activeSection, setActiveSection] = useState<'routes' | 'skills' | 'mcp'>('routes');

  const [modelRoutes] = useState<ModelRoute[]>([
    { id: '1', name: 'GPT-4', endpoint: 'https://api.openai.com/v1', apiKey: 'sk-***', priority: 1 },
    { id: '2', name: 'Claude-3', endpoint: 'https://api.anthropic.com/v1', apiKey: 'sk-***', priority: 2 },
    { id: '3', name: 'Local LLM', endpoint: 'http://localhost:11434', apiKey: 'none', priority: 3 },
  ]);

  const [skills] = useState<Skill[]>([
    { id: '1', name: 'Code Generation', description: '生成高质量代码', enabled: true },
    { id: '2', name: 'Code Review', description: '自动代码审查', enabled: true },
    { id: '3', name: 'Documentation', description: '生成文档', enabled: false },
    { id: '4', name: 'Testing', description: '生成测试用例', enabled: true },
  ]);

  const [mcpServers] = useState<MCPServer[]>([
    { id: '1', name: 'GitHub MCP', url: 'mcp://github.com', status: 'connected' },
    { id: '2', name: 'Linear MCP', url: 'mcp://linear.app', status: 'connected' },
    { id: '3', name: 'Slack MCP', url: 'mcp://slack.com', status: 'disconnected' },
  ]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-white rounded-lg shadow-2xl w-[800px] max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">模型配置</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 px-6">
          <button
            onClick={() => setActiveSection('routes')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeSection === 'routes'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            模型路由管理
          </button>
          <button
            onClick={() => setActiveSection('skills')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeSection === 'skills'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Skills 管理
          </button>
          <button
            onClick={() => setActiveSection('mcp')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeSection === 'mcp'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            MCP 管理
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeSection === 'routes' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-gray-600">管理 AI 模型的路由配置和优先级</p>
                <Button variant="small">
                  <Plus className="w-4 h-4 mr-1" />
                  添加路由
                </Button>
              </div>
              {modelRoutes.map((route) => (
                <div key={route.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-gray-900">{route.name}</h4>
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
                          优先级 {route.priority}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-1">Endpoint: {route.endpoint}</p>
                      <p className="text-sm text-gray-600">API Key: {route.apiKey}</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-red-600 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeSection === 'skills' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-gray-600">启用或禁用 AI Agent 的技能模块</p>
                <Button variant="small">
                  <Plus className="w-4 h-4 mr-1" />
                  添加技能
                </Button>
              </div>
              {skills.map((skill) => (
                <div key={skill.id} className="border border-gray-200 rounded-lg p-4 flex items-center justify-between hover:border-blue-300 transition-colors">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{skill.name}</h4>
                    <p className="text-sm text-gray-600">{skill.description}</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" checked={skill.enabled} readOnly className="sr-only peer" />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
              ))}
            </div>
          )}

          {activeSection === 'mcp' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-gray-600">管理 Model Context Protocol 服务器连接</p>
                <Button variant="small">
                  <Plus className="w-4 h-4 mr-1" />
                  添加服务器
                </Button>
              </div>
              {mcpServers.map((server) => (
                <div key={server.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-gray-900">{server.name}</h4>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full ${
                            server.status === 'connected'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {server.status === 'connected' ? '已连接' : '未连接'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{server.url}</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-red-600 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-200">
          <Button variant="ghost" onClick={onClose}>
            取消
          </Button>
          <Button variant="primary" onClick={onClose}>
            保存更改
          </Button>
        </div>
      </div>
    </div>
  );
}
