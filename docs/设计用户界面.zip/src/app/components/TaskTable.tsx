import { useState, useMemo } from 'react';
import { Search, Filter } from 'lucide-react';
import { WorkItem, TaskStatus } from '../types';
import { Badge } from './Badge';
import { getPriorityLabel } from '../utils/status-utils';

interface TaskTableProps {
  items: WorkItem[];
  onRowClick: (item: WorkItem) => void;
}

export function TaskTable({ items, onRowClick }: TaskTableProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<TaskStatus | 'all'>('all');

  // Filter and search items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchesSearch =
        searchQuery === '' ||
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.number.toString().includes(searchQuery);

      const matchesStatus = statusFilter === 'all' || item.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [items, searchQuery, statusFilter]);

  return (
    <div className="flex flex-col h-full">
      {/* Filters & Search */}
      <div className="p-4 border-b" style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-surface)' }}>
        <div className="flex gap-3 items-center">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4" style={{ color: 'var(--color-text-secondary)' }} />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as TaskStatus | 'all')}
              className="px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2"
              style={{ 
                borderColor: 'var(--color-border)', 
                backgroundColor: 'var(--color-background)',
                color: 'var(--color-text)'
              }}
            >
              <option value="all">所有状态</option>
              <option value="pending">待办</option>
              <option value="ready">就绪</option>
              <option value="in_progress">进行中</option>
              <option value="verifying">验证中</option>
              <option value="blocked">阻塞</option>
              <option value="done">完成</option>
            </select>
          </div>

          <div className="flex-1 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--color-text-secondary)' }} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索任务..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2"
              style={{ 
                borderColor: 'var(--color-border)', 
                backgroundColor: 'var(--color-background)',
                color: 'var(--color-text)'
              }}
            />
          </div>

          <div className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
            共 {filteredItems.length} 个任务
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full">
          <thead className="border-b sticky top-0" style={{ backgroundColor: 'var(--color-surface-hover)', borderColor: 'var(--color-border)' }}>
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--color-text-secondary)' }}>
                编号
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--color-text-secondary)' }}>
                标题
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--color-text-secondary)' }}>
                Epic
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--color-text-secondary)' }}>
                Story
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--color-text-secondary)' }}>
                状态
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--color-text-secondary)' }}>
                优先级
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--color-text-secondary)' }}>
                阻塞
              </th>
            </tr>
          </thead>
          <tbody className="divide-y" style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
            {filteredItems.map((item) => (
              <tr
                key={item.number}
                onClick={() => onRowClick(item)}
                className="cursor-pointer transition-colors"
                style={{ backgroundColor: 'var(--color-surface)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-surface-hover)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--color-surface)';
                }}
              >
                <td className="px-4 py-3 text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                  #{item.number}
                </td>
                <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-text)' }}>
                  <div className="max-w-md truncate">{item.title}</div>
                </td>
                <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-text-secondary)' }}>
                  {item.epicNumber ? `#${item.epicNumber}` : '—'}
                </td>
                <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-text-secondary)' }}>
                  {item.storyNumber ? `#${item.storyNumber}` : '—'}
                </td>
                <td className="px-4 py-3">
                  <Badge status={item.status} />
                </td>
                <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-text)' }}>
                  {getPriorityLabel(item.priority)}
                </td>
                <td className="px-4 py-3 text-sm text-red-600">
                  {item.blockedReason || '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}