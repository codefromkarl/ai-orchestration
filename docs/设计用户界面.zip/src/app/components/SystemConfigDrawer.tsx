import { X, Sun, Moon, Zap, Code } from 'lucide-react';
import { Button } from './Button';

export type Theme = 'light' | 'dark' | 'cyberpunk' | 'programmer';

interface SystemConfigDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: Theme;
  onThemeChange: (theme: Theme) => void;
}

const themes = [
  {
    id: 'light' as Theme,
    name: '亮色主题',
    description: '清新明亮的界面风格',
    icon: Sun,
    preview: 'bg-gradient-to-br from-white to-gray-100',
  },
  {
    id: 'dark' as Theme,
    name: '暗色主题',
    description: '护眼的深色界面',
    icon: Moon,
    preview: 'bg-gradient-to-br from-gray-800 to-gray-900',
  },
  {
    id: 'cyberpunk' as Theme,
    name: '赛博朋克',
    description: '未来感的霓虹风格',
    icon: Zap,
    preview: 'bg-gradient-to-br from-purple-900 via-pink-800 to-blue-900',
  },
  {
    id: 'programmer' as Theme,
    name: '程序员风格',
    description: '代码编辑器的经典配色',
    icon: Code,
    preview: 'bg-gradient-to-br from-slate-900 via-green-900 to-slate-800',
  },
];

export function SystemConfigDrawer({ isOpen, onClose, currentTheme, onThemeChange }: SystemConfigDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-white rounded-lg shadow-2xl w-[700px] max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">系统配置</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            {/* Theme Section */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">主题管理</h3>
              <p className="text-sm text-gray-600 mb-6">选择您喜欢的界面主题风格</p>

              <div className="grid grid-cols-2 gap-4">
                {themes.map((theme) => {
                  const Icon = theme.icon;
                  const isActive = currentTheme === theme.id;

                  return (
                    <button
                      key={theme.id}
                      onClick={() => onThemeChange(theme.id)}
                      className={`relative p-4 rounded-lg border-2 transition-all ${
                        isActive
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                      }`}
                    >
                      {/* Theme Preview */}
                      <div className={`w-full h-24 rounded-md mb-3 ${theme.preview} flex items-center justify-center`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>

                      {/* Theme Info */}
                      <div className="text-left">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-semibold text-gray-900">{theme.name}</h4>
                          {isActive && (
                            <span className="text-xs bg-blue-600 text-white px-2 py-0.5 rounded-full">
                              当前
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-600">{theme.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Other Settings */}
            <div className="pt-6 border-t border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">其他设置</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">动画效果</p>
                    <p className="text-sm text-gray-600">启用界面过渡动画</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" defaultChecked className="sr-only peer" />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">声音提示</p>
                    <p className="text-sm text-gray-600">任务状态变化时播放声音</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">自动刷新</p>
                    <p className="text-sm text-gray-600">每 30 秒自动刷新数据</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" defaultChecked className="sr-only peer" />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-200">
          <Button variant="ghost" onClick={onClose}>
            取消
          </Button>
          <Button variant="primary" onClick={onClose}>
            保存更改
          </Button>
        </div>
      </div>
    </div>
  );
}
