import { Diamond, Settings, Cpu } from 'lucide-react';

interface TopNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenModelConfig: () => void;
  onOpenSystemConfig: () => void;
}

export function TopNav({ activeTab, onTabChange, onOpenModelConfig, onOpenSystemConfig }: TopNavProps) {
  const tabs = [
    { id: 'kanban', label: '信息室' },
    { id: 'command', label: '指挥所' },
    { id: 'repository', label: '任务仓库' },
  ];

  return (
    <div className="h-12 border-b bg-white flex items-center px-6 justify-between" style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-surface)' }}>
      {/* Logo & Brand */}
      <div className="flex items-center gap-2">
        <Diamond className="w-5 h-5" style={{ color: 'var(--color-primary)' }} fill="currentColor" />
        <span className="font-semibold text-lg" style={{ color: 'var(--color-text)' }}>Stardrifter</span>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
              activeTab === tab.id
                ? 'text-white shadow-sm'
                : 'hover:bg-opacity-10'
            }`}
            style={
              activeTab === tab.id
                ? { 
                    background: `linear-gradient(to right, var(--color-primary), var(--color-primary-hover))` 
                  }
                : { 
                    color: 'var(--color-text-secondary)',
                    backgroundColor: 'transparent'
                  }
            }
            onMouseEnter={(e) => {
              if (activeTab !== tab.id) {
                e.currentTarget.style.backgroundColor = 'var(--color-surface-hover)';
              }
            }}
            onMouseLeave={(e) => {
              if (activeTab !== tab.id) {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <input
          type="text"
          placeholder="codefromkarl/stardrifter"
          className="px-3 py-1 text-sm border rounded-md w-48"
          style={{ 
            borderColor: 'var(--color-border)', 
            backgroundColor: 'var(--color-surface-hover)',
            color: 'var(--color-text)'
          }}
          defaultValue="codefromkarl/stardrifter"
        />
        <button
          onClick={onOpenModelConfig}
          className="p-2 rounded-md transition-colors"
          style={{ color: 'var(--color-text-secondary)' }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--color-primary)';
            e.currentTarget.style.backgroundColor = 'var(--color-surface-hover)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--color-text-secondary)';
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
          title="模型配置"
        >
          <Cpu className="w-5 h-5" />
        </button>
        <button
          onClick={onOpenSystemConfig}
          className="p-2 rounded-md transition-colors"
          style={{ color: 'var(--color-text-secondary)' }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--color-primary)';
            e.currentTarget.style.backgroundColor = 'var(--color-surface-hover)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--color-text-secondary)';
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
          title="系统配置"
        >
          <Settings className="w-5 h-5" />
        </button>
        <select 
          className="px-2 py-1 text-sm border rounded-md"
          style={{ 
            borderColor: 'var(--color-border)', 
            backgroundColor: 'var(--color-surface-hover)',
            color: 'var(--color-text)'
          }}
        >
          <option>中文</option>
          <option>EN</option>
        </select>
      </div>
    </div>
  );
}