import { X, ExternalLink } from 'lucide-react';
import { WorkItem } from '../types';
import { Badge } from './Badge';
import { getStatusLabel, getPriorityLabel } from '../utils/status-utils';

interface DetailDrawerProps {
  item: WorkItem | null;
  onClose: () => void;
}

export function DetailDrawer({ item, onClose }: DetailDrawerProps) {
  if (!item) return null;

  return (
    <div className="w-[360px] border-l flex flex-col h-full" style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-surface)' }}>
      {/* Header */}
      <div className="flex items-start justify-between p-4 border-b" style={{ borderColor: 'var(--color-border)' }}>
        <div className="flex-1 pr-2">
          <h3 className="font-semibold" style={{ color: 'var(--color-text)' }}>
            #{item.number} {item.title}
          </h3>
        </div>
        <button
          onClick={onClose}
          className="transition-colors"
          style={{ color: 'var(--color-text-secondary)' }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--color-text)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--color-text-secondary)';
          }}
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Metadata Grid */}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-x-3 gap-y-2 text-sm">
            <div style={{ color: 'var(--color-text-secondary)' }}>Type</div>
            <div className="font-medium" style={{ color: 'var(--color-text)' }}>{item.type}</div>

            <div style={{ color: 'var(--color-text-secondary)' }}>Status</div>
            <div><Badge status={item.status} /></div>

            {item.lane && (
              <>
                <div style={{ color: 'var(--color-text-secondary)' }}>Lane</div>
                <div className="font-medium" style={{ color: 'var(--color-text)' }}>{item.lane}</div>
              </>
            )}

            {item.wave && (
              <>
                <div style={{ color: 'var(--color-text-secondary)' }}>Wave</div>
                <div className="font-medium" style={{ color: 'var(--color-text)' }}>{item.wave}</div>
              </>
            )}

            {item.complexity && (
              <>
                <div style={{ color: 'var(--color-text-secondary)' }}>Complexity</div>
                <div className="font-medium" style={{ color: 'var(--color-text)' }}>{item.complexity}</div>
              </>
            )}
          </div>
        </div>

        {/* Work Status Section */}
        <div className="pt-3 border-t space-y-2" style={{ borderColor: 'var(--color-border)' }}>
          <div className="flex items-center justify-between text-sm">
            <span style={{ color: 'var(--color-text-secondary)' }}>Work status</span>
            <Badge status={item.status} />
          </div>

          {item.blockedReason && (
            <div className="flex items-center justify-between text-sm">
              <span style={{ color: 'var(--color-text-secondary)' }}>Blocked</span>
              <span className="text-red-600 font-medium">{item.blockedReason}</span>
            </div>
          )}

          {item.decisionRequired && (
            <div className="flex items-center justify-between text-sm">
              <span style={{ color: 'var(--color-text-secondary)' }}>Decision Required</span>
              <span className="text-orange-600 font-medium">Yes</span>
            </div>
          )}
        </div>

        {/* Epic & Story */}
        {(item.epicNumber || item.storyNumber) && (
          <div className="pt-3 border-t space-y-2 text-sm" style={{ borderColor: 'var(--color-border)' }}>
            {item.epicNumber && (
              <div className="flex items-center justify-between">
                <span style={{ color: 'var(--color-text-secondary)' }}>Epic</span>
                <span className="font-medium" style={{ color: 'var(--color-primary)' }}>#{item.epicNumber}</span>
              </div>
            )}
            {item.storyNumber && (
              <div className="flex items-center justify-between">
                <span style={{ color: 'var(--color-text-secondary)' }}>Story</span>
                <span className="font-medium" style={{ color: 'var(--color-primary)' }}>#{item.storyNumber}</span>
              </div>
            )}
          </div>
        )}

        {/* Priority */}
        <div className="pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
          <div className="flex items-center justify-between text-sm">
            <span style={{ color: 'var(--color-text-secondary)' }}>Priority</span>
            <span className="font-medium" style={{ color: 'var(--color-text)' }}>{getPriorityLabel(item.priority)}</span>
          </div>
        </div>

        {/* External Link */}
        {item.githubUrl && (
          <div className="pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
            <a
              href={item.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: 'var(--color-primary)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-primary-hover)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-primary)';
              }}
            >
              <ExternalLink className="w-4 h-4" />
              <span>GitHub Issue</span>
            </a>
          </div>
        )}
      </div>
    </div>
  );
}