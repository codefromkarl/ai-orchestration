import { TaskStatus } from '../types';
import { getStatusColor, getStatusLabel } from '../utils/status-utils';

interface BadgeProps {
  status: TaskStatus;
}

export function Badge({ status }: BadgeProps) {
  const colors = getStatusColor(status);
  const label = getStatusLabel(status);

  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold"
      style={{
        backgroundColor: colors.bg,
        color: colors.text,
      }}
    >
      {label}
    </span>
  );
}
