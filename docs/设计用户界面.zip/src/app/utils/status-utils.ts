import { TaskStatus, Priority } from '../types';

export const statusColors: Record<TaskStatus, { bg: string; text: string; color: string }> = {
  pending: {
    bg: '#f1f5f9',
    text: '#64748b',
    color: '#94a3b8',
  },
  ready: {
    bg: '#fef3c7',
    text: '#92400e',
    color: '#fbbf24',
  },
  in_progress: {
    bg: '#dbeafe',
    text: '#1d4ed8',
    color: '#3b82f6',
  },
  verifying: {
    bg: '#f3e8ff',
    text: '#6b21a8',
    color: '#a855f7',
  },
  blocked: {
    bg: '#fee2e2',
    text: '#991b1b',
    color: '#ef4444',
  },
  done: {
    bg: '#dcfce7',
    text: '#166534',
    color: '#22c55e',
  },
};

export const statusLabels: Record<TaskStatus, string> = {
  pending: '待办',
  ready: '就绪',
  in_progress: '进行中',
  verifying: '验证中',
  blocked: '阻塞',
  done: '完成',
};

export const priorityLabels: Record<Priority, string> = {
  governance: '治理',
  core_path: '核心路径',
  cross_cutting: '横切关注',
};

export function getStatusColor(status: TaskStatus) {
  return statusColors[status];
}

export function getStatusLabel(status: TaskStatus) {
  return statusLabels[status];
}

export function getPriorityLabel(priority: Priority) {
  return priorityLabels[priority];
}
