import { Theme } from '../components/SystemConfigDrawer';

interface ThemeConfig {
  background: string;
  surface: string;
  surfaceHover: string;
  border: string;
  text: string;
  textSecondary: string;
  primary: string;
  primaryHover: string;
  accent: string;
}

export const themeConfigs: Record<Theme, ThemeConfig> = {
  light: {
    background: '#ffffff',
    surface: '#f9fafb',
    surfaceHover: '#f3f4f6',
    border: '#e5e7eb',
    text: '#111827',
    textSecondary: '#6b7280',
    primary: '#3b82f6',
    primaryHover: '#2563eb',
    accent: '#8b5cf6',
  },
  dark: {
    background: '#0f172a',
    surface: '#1e293b',
    surfaceHover: '#334155',
    border: '#334155',
    text: '#f1f5f9',
    textSecondary: '#94a3b8',
    primary: '#3b82f6',
    primaryHover: '#2563eb',
    accent: '#8b5cf6',
  },
  cyberpunk: {
    background: '#0a0a1f',
    surface: '#1a1a3e',
    surfaceHover: '#2a2a5e',
    border: '#ff00ff',
    text: '#00ffff',
    textSecondary: '#ff00ff',
    primary: '#ff00ff',
    primaryHover: '#cc00cc',
    accent: '#00ffff',
  },
  programmer: {
    background: '#1e1e1e',
    surface: '#252526',
    surfaceHover: '#2d2d30',
    border: '#3e3e42',
    text: '#d4d4d4',
    textSecondary: '#858585',
    primary: '#4ec9b0',
    primaryHover: '#3ea88c',
    accent: '#569cd6',
  },
};

export function applyTheme(theme: Theme) {
  const config = themeConfigs[theme];
  const root = document.documentElement;

  root.style.setProperty('--color-background', config.background);
  root.style.setProperty('--color-surface', config.surface);
  root.style.setProperty('--color-surface-hover', config.surfaceHover);
  root.style.setProperty('--color-border', config.border);
  root.style.setProperty('--color-text', config.text);
  root.style.setProperty('--color-text-secondary', config.textSecondary);
  root.style.setProperty('--color-primary', config.primary);
  root.style.setProperty('--color-primary-hover', config.primaryHover);
  root.style.setProperty('--color-accent', config.accent);

  // Store theme preference
  localStorage.setItem('stardrifter-theme', theme);
}

export function getStoredTheme(): Theme {
  const stored = localStorage.getItem('stardrifter-theme');
  return (stored as Theme) || 'light';
}
