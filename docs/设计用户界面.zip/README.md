
  # 设计用户界面

  This is a code bundle for 设计用户界面. The original project is available at https://www.figma.com/design/eApwIbH5DDibObyiYfOPT3/%E8%AE%BE%E8%AE%A1%E7%94%A8%E6%88%B7%E7%95%8C%E9%9D%A2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  